let s = (id) => {
    return document.getElementById(id);
};

let q = (query) => {
    return document.querySelectorAll(query);
};

async function onClick()
{
    const [tab] = await chrome.tabs.query(
        {
            active: true,
            currentWindow: true
        }
    );

    const config = {
        range: s('targetRange').value,
        before: s('before').value,
        flags: s('flags').value,
        after: s('after').value
    };

    if (!config.before)
    {
        alert('検索する正規表現を入力してください');
        return;
    }

    chrome.scripting.executeScript(
        {
            target: {
                tabId: tab.id
            },

            func: executeReplacement,
            args: [config]
        }
    );
}

s('replaceBtn').onclick = onClick;

// この関数がContent Scriptとして注入されます
function executeReplacement(config)
{
    const regex = new RegExp(config.before, config.flags);

    if (config.range === 'form')
    {
        // フォーム要素（input, textarea）のみを対象
        const inputs = q(
            'input[type="text"], input[type="search"], textarea'
        );

        inputs.forEach(
            el => {
                el.value = el.value.replace(regex, config.after);
            }
        );
    } else {
        // HTML全体のテキストノードを対象（UIを壊さないよう再帰的に処理）
        const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false);
        let node;
        const nodes = [];

        while (node = walker.nextNode())
        {
            nodes.push(node);
        }

        nodes.forEach(
            textNode => {
                if (textNode.parentElement.tagName !== 'SCRIPT' && textNode.parentElement.tagName !== 'STYLE')
                {
                    textNode.nodeValue = textNode.nodeValue.replace(regex, config.after);
                }
            }
        );
    }
}